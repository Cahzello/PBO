<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
        <title><?php echo $title; ?></title>
    </head>
    <body>
        <div class="container">
        <div class="row mt-3">
            <h1 align="center">Tambah Aktivitas Data</h1>
        </div>
        <form action="<?php echo site_url('C_utama/add'); ?>" method="post" enctype="multipart/form-data" >
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Tanggal</label>
                <input type="date" name="tanggal" class="form-control" placeholder="Masukkan Tanggal">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Jam Masuk</label>
                <input type="time" name="jam_masuk" class="form-control" placeholder="Masukkan Jam Masuk">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Aktivitas</label>
                <input type="text" name="log_aktivitas" class="form-control" placeholder="Masukkan Aktivitas">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Jam Keluar</label>
                <input type="time" name="jam_keluar" class="form-control" placeholder="Masukkan Jam Keluar">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Output</label>
                <input type="text" name="output" class="form-control" placeholder="Masukkan Output">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">File</label>
                <input type="file" name="file" class="form-control">
            </div>
            <input type="submit" name="submit" value="Submit">
        </form>
        </div>
    </body>
</html>