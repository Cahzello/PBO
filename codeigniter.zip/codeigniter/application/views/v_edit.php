<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
        <title><?php echo $jdl; ?></title>
    </head>
    <body>
        <div class="container">
            <div class="row mt-3">
                <h1 align="center">Edit Data Aktivitas</h1>
            </div>
            <form action="<?php echo site_url('C_utama/updateData/'); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $aktivitas->id; ?>"> 
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" value="<?php echo $aktivitas->tanggal; ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Jam Masuk</label>
                    <input type="time" name="jam_masuk" value="<?php echo $aktivitas->jam_masuk; ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Aktivitas</label>
                    <input type="text" name="log_aktivitas" value="<?php echo $aktivitas->log_aktivitas; ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Jam Keluar</label>
                    <input type="time" name="jam_keluar" value="<?php echo $aktivitas->jam_keluar; ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Output</label>
                    <input type="text" name="output" value="<?php echo $aktivitas->output; ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">File</label>
                    <input type="file" name="file" value="<?php echo $aktivitas->file; ?>" class="form-control">
                </div>
                <input type="submit" name="submit" value="Update">
            </form>
        </div>
    </body>
</html>