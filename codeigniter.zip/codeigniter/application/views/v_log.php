<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $judul; ?></title>
	</head>
	<body>
		<div class="container">
			<div class="row mt-3">
				<div class="col-md-6">
					<p align="center">
						<?php echo anchor('C_utama/daftar/',"Menambahkan data aktivitas log"); ?>
					</p>
				</div>
			</div>
			<table class="table">
			  	<thead class="thead-dark">
			   	   	<tr>
				      	<th scope="col">Nomor</th>
				      	<th scope="col">Tanggal</th>
				      	<th scope="col">Jam Masuk</th>
				      	<th scope="col">Log Aktivitas</th>
				      	<th scope="col">Jam Keluar</th>
				      	<th scope="col">Output</th>
				      	<th scope="col">File</th>
				      	<th scope="col">Aksi</th>
			    	</tr>
			  	</thead>
			  	<tbody>
				    <?php
					$nomor = 1;
						foreach ($aktivitas as $data) {
					?>
			        <tr>
			           	<th scope="row"><?php echo $nomor; ?></th>
					    <td><?php echo $data->tanggal; ?></td>
					    <td><?php echo $data->jam_masuk; ?></td>
					    <td><?php echo $data->log_aktivitas; ?></td>
					    <td><?php echo $data->jam_keluar; ?></td>
					    <td><?php echo $data->output; ?></td>
					    <td><?php echo $data->file; ?></td>
					    <td align="center"> 
			  				<a href="<?php echo site_url('C_utama/editData/')?><?php echo $data->id?>" class="btn btn-sm btn-primary">Edit</a>
					        <a href="<?php echo site_url('C_utama/hapusData/')?><?php echo $data->id?>" "Delete" onclick="return confirm('Yakin Hapus?')"class="btn btn-sm btn-danger">Delete</a>
					    </td> 
			       	<?php
						$nomor++;
						}
					?>
			    	</tr>
			    </tbody>
			</table>
		</div>
	</body>
</html>