<!DOCTYPE html>
<html>
	<head>
		<title> Home </title>
	</head>
	<body>
		<h1> Ini Merupakan Home </h1>
		<p> Selamat Belajar CI </p>
		<p> Selamat Datang </p>
		<?php 
			echo anchor('C_utama/aktivitas', 'Menampilkan data aktivitas');
		?>
	</body>
</html>