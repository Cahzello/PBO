<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Aktivitas extends CI_Model{
		public function getAll(){
			$query = $this->db->get('tbl_log');
			return $query->result();
		}

		public function getById($id){
            $this->db->where('id', $id);
            $query = $this->db->get('tbl_log');
            return $query->row();
        }

		public function save_insert($data){
            $simpan = $this->db->insert('tbl_log' , $data);
            if($simpan){
                return true;
            }else{
                return false;
            }
        }

        public function save_delete($id){
            $this->db->where('id', $id);
            $del = $this->db->delete('tbl_log');
            if($del){
                return true;
            }else{
                return false;
            }
        }

        public function save_update($id, $data){
            $this->db->where('id', $id);
            $update = $this->db->update('tbl_log', $data);
            if($update){
                return true;
            }else{
                return false;
            }
        }
	}
?>