<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_utama extends CI_Controller {

	//Otomatis akan dipanggil
	public function index(){
		$log = $this->Aktivitas->getAll();

		$temp['aktivitas'] = $log;
		$temp['judul'] = "Aktivitas Log";
		$this->load->view('templates/header');
		$this->load->view('v_log', $temp);
		$this->load->view('templates/footer');
	}

	//Menampilkan form pendaftaran (data baru)
	public function daftar(){
		$this->load->view('templates/header');
		$this->load->view('v_add');
		$this->load->view('templates/footer');
	}

	//Menambahkan data
	public function add(){
		
		$tgl = $this->input->post('tanggal');
		$jamMasuk = $this->input->post('jam_masuk');
		$aktivitasLog = $this->input->post('log_aktivitas');
		$jamKeluar = $this->input->post('jam_keluar');
		$output = $this->input->post('output');
		$file = $_FILES['file'];
		if ($file = '') {
			# code...
		}else{
			$config['upload_path'] = './upload';
			$config['allowed_types'] = 'pdf|jpg|png|docs';

			$this->load->library('upload', $config);
			if(!$this->upload->do_upload('file')){
				echo "Upload Failed!";
			}else{
				$file = $this->upload->data('file_name');
			}
		}

		$data = array(
			'tanggal' => $tgl,
			'jam_masuk' => $jamMasuk,
			'log_aktivitas' => $aktivitasLog,
			'jam_keluar' => $jamKeluar,
			'output' => $output,
			'file' => $file
		);

		$simpan = $this->Aktivitas->save_insert($data);
		if ($simpan) {
			redirect('C_utama/index');
		}
	}

	//Respon setelah tombol hapus ditekan
	public function hapusData($id){
		$del = $this->Aktivitas->save_delete($id);
		if($del){
			redirect('C_utama/index');
		}
	}

	//Respon setelah tombol edit ditekan
	public function editData($id){
		$log = $this->Aktivitas->getById($id);
		
		$temp['jdl'] = "Edit Table";
		$temp['aktivitas'] = $log;
		$this->load->view('templates/header');
		$this->load->view('v_edit', $temp);
		$this->load->view('templates/footer');
	}

	//Respon setelah form update diisi
	public function updateData(){
		$id = $this->input->post('id');
		$tgl = $this->input->post('tanggal');
		$jamMasuk = $this->input->post('jam_masuk');
		$aktivitasLog = $this->input->post('log_aktivitas');
		$jamKeluar = $this->input->post('jam_keluar');
		$output = $this->input->post('output');
		$file = $_FILES['file'];
		if ($file = '') {
			# code...
		}else{
			$config['upload_path'] = './upload';
			$config['allowed_types'] = 'pdf|jpg|png|docs';

			$this->load->library('upload', $config);
			if(!$this->upload->do_upload('file')){
				echo "Upload Failed!";
			}else{
				$file = $this->upload->data('file_name');
			}
		}

		$data = array(
			'tanggal' => $tgl,
			'jam_masuk' => $jamMasuk,
			'log_aktivitas' => $aktivitasLog,
			'jam_keluar' => $jamKeluar,
			'output' => $output,
			'file' => $file
		);

		$update = $this->Aktivitas->save_update($id, $data);
		if($update){
			redirect('C_utama/index');
		}
	}
}